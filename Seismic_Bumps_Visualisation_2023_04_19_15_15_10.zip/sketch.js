let table;
let numRows, numCols;
let v1 = [], v2 = [],v3 = [],v4 = [],v5 = [],v6 = [],v7 = [],sclass = [];
let diagramX, diagramY;
function preload() {
  table = loadTable("assets/seismic-bumps_csv.csv","csv","header");
}


function setup() {
  createCanvas(windowWidth, windowHeight);
  rectMode(CENTER)
  // extracting base data
  numRows = table.getRowCount();
  numCols = table.getColumnCount();
  //print("rows: " + numRows + "cols:" + numCols)
  
  //inserting and loading the data
  
  for(let r= 0; r<table.getRowCount(); r++){
    v1[r] = table.getNum(r,0);
    v2[r] = table.getNum(r,1);
    v3[r] = table.getNum(r,2);
    v4[r] = table.getNum(r,3);
    v5[r] = table.getNum(r,4);
    v6[r] = table.getNum(r,5);
    v7[r] = table.getNum(r,6);
    sclass[r] = table.getNum(r,7);
    print(v1[r] + " " +v2[r] + " " + v3[r] + " " + v4[r] + " " + v5[r] + " " + v6[r] + " " + v7[r] + " " + sclass[r])
    
  }
  minMax();
}
let size = [];
function draw() {
  background(244);
  chartInfo();
  diagramX = (width/4)*3-90;
  diagramY = height/2;
  let radius = width/5-100;
  let ang = 360 / numRows;
  
  for (let n = 0; n<numRows; n++){
    size[n] = map(v1[n],10.59,21.18,0,225);
    let pointx = (size[n]+radius)*cos(radians(ang*n))+diagramX;
    let pointy = (size[n]+radius)*sin(radians(ang*n))+diagramY;
    let circx = radius*cos(radians(ang*n))+diagramX;
    let circy = radius*sin(radians(ang*n))+diagramY;
    
    //drawing the indication line
    if(n % 12 ===0){
      strokeWeight(2);
      stroke('green')
    }else{
    stroke('black')
    strokeWeight(0.3);
    }
    line(circx,circy,pointx,pointy)
    
    //hovering on data effect
    let datasize;
    let dis = dist(mouseX,mouseY,pointx,pointy);
    if(dis<5){
      fill('red')
      datasize = 12;
      noStroke();
      circle(pointx,pointy,datasize);
      //drawing information regarding a selected dot
      textAlign(CENTER)
      textSize(25);
      fill('black')
      text(sclass[n],diagramX,diagramY)
      fill('orange')
      rect(diagramX,diagramY + 10,18,7)
      textSize(20);
      text(v1[n],diagramX,diagramY+30);
    }else{
      fill('yellow')
      datasize = 4;
      noStroke();
      circle(pointx,pointy,datasize);
    }
    
    //drawing the acquired data
    fill('red')
    noStroke();
    circle(pointx,pointy,datasize);
  }
  
function chartInfo(){
  textSize(10);
  textAlign(LEFT);
  fill('black');
  text("Mining activity was and is always connected with the occurrence of dangers which are commonly called mining hazards. A special case of such threat is a seismic hazard which frequently occurs in many underground mines. Seismic hazard is the hardest detectable and predictable of natural hazards and in this respect it is comparable to an earthquake. More and more advanced seismic and seismoacoustic monitoring systems allow a better understanding rock mass processes and definition of seismic hazard prediction methods. Accuracy of so far created methods is however far from perfect. Complexity of seismic processes and big disproportion between the number of low-energy seismic events and the number of high-energy phenomena (e.g. > 10^4J) causes the statistical techniques to be insufficient to predict seismic hazard. Therefore, it is essential to search for new opportunities of better hazard prediction, also using machine learning methods. In seismic hazard assessment data clustering techniques can be applied (Lesniak A., Isakow Z.: Space-time clustering of seismic events and hazard assessment in the Zabrze-Bielszowice coal mine, Poland. Int. Journal of Rock Mechanics and Mining Sciences, 46(5), 2009, 918-928), and for prediction of seismic tremors artificial neural networks are used (Kabiesz, J.: Effect of the form of data on the quality of mine tremors hazard forecasting using neural networks. Geotechnical and Geological Engineering, 24(5), 2005, 1131-1147). In the majority of applications, the results obtained by mentioned methods are reported in the form of two states which are interpreted as ‘hazardous’ and ‘non-hazardous’. Unbalanced distribution of positive (‘hazardous state’) and negative (‘non-hazardous state’) examples is a serious problem in seismic hazard prediction. Currently used methods are still insufficient to achieve good sensitivity and specificity of predictions. In the paper (Bukowska M.: The probability of rockburst occurrence in the Upper Silesian Coal Basin area dependent on natural mining conditions. Journal of Mining Sciences, 42(6), 2006, 570-577) a number of factors having an effect on seismic hazard occurrence was proposed, among other factors, the occurrence of tremors with energy > 10^4J was listed. The task of seismic prediction can be defined in different ways, but the main aim of all seismic hazard assessment methods is to predict (with given precision relating to time and date) of increased seismic activity which can cause a rockburst. In the data set each row contains a summary statement about seismic activity in the rock mass within one shift (8 hours). If decision attribute has the value 1, then in the next shift any seismic bump with an energy higher than 10^4 J was registered. That task of hazards prediction bases on the relationship between the energy of recorded tremors and seismoacoustic activity with the possibility of rockburst occurrence. Hence, such hazard prognosis is not connected with accurate rockburst prediction. Moreover, with the information about the possibility of hazardous situation occurrence, an appropriate supervision service can reduce a risk of rockburst (e.g. by distressing shooting) or withdraw workers from the threatened area. Good prediction of increased seismic activity is therefore a matter of great practical importance. The presented data set is characterized by unbalanced distribution of positive and negative examples. In the data set there are only 170 positive examples representing class 1.",width/4,height/4-100,width/4)
  textSize(20);
  text('Seismic Bumps',width/4,height/4-120,width/4);
}
  
}

let dataMin, dataMax = 0;
function minMax(){
  for(let n=0;n<numRows;n++){
    if(table.getNum(n,0)>dataMax){
      dataMax = table.getNum(n,0);
    }
      }
  dataMin = dataMax;
  for(let n=0; n<numRows; n++){
    if(table.getNum(n,0)<dataMin){
      dataMin = table.getNum(n,0);
    }
  }
  print("max value" + dataMax + "min value" + dataMin)
}